package car_kiosk;

import javax.swing.JFrame;

public class test extends JFrame {
	
	
	
	public static void main(String[] args) {
		
		
		
//		CustomerDAO customerDAO = CustomerDAO.getInstance();
//		
//		List<CarDTO> carList;
//		carList = CarDAO.getInstance().GetTable();
//		
//		for (CarDTO carDTO : carList) {
//			if(carDTO.getCar_Name().equals("쏘렌토")) {
//			System.out.println(carDTO.getIsKey());
//			}
//		}
	}

}
