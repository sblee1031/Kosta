package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class SQLiteTest {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Connection con = null;
		ResultSet rs = null;
		try {
			Class.forName("org.sqlite.JDBC");
			
			String dbFile = "E:\\JAVA_WORK\\Work\\car_kiosk\\db\\carKiosk.db";
			con = DriverManager.getConnection("jdbc:sqlite:"+dbFile);
			
			Statement stat = con.createStatement();
			System.out.println("DB Connection!");
			
			String sql = "INSERT INTO carKiosk values (?, ?)";
			PreparedStatement prep = con.prepareStatement(
//					"INSERT into carKiosk (userName, ph_Num) VALUES ('userName2', 01022);"
//					"DELETE FROM carKiost WHERE userName='김김동';"
					sql
					);
			prep.setString(1, "name");
			prep.setString(2, "age");
			prep.executeLargeUpdate();
			rs = stat.executeQuery(sql);
//			while(rs.next()) {
//				String id = rs.getString("userName");
//				String name = rs.getString("ph_Num");
//				
//				System.out.println(id + "      " + name);
//				break;
//			}
			rs.close();
			con.close();
			System.out.println("DB DisConnection----");
			
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(con!=null) {
				try {con.close();}catch(Exception e) {}
			}
		}
		
		
	}

}
