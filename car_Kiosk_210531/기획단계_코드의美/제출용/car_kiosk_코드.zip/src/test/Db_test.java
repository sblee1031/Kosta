package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Db_test {
	
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		loadMenu();
		

	}

	public static List<String[]> saleList = new ArrayList<String[]>();
	public static void loadMenu() {

		File file = new File(".\\txt\\db.txt");

		String[] splitedStr = null;


		try {

	//한글 깨짐현상 때문에 인코딩

			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));



			String line = null;

			splitedStr = null;



			while ((line = reader.readLine()) != null) {



				splitedStr = null;

				splitedStr = line.split("\t");



				for (int i = 0; i < splitedStr.length; i++) {

					splitedStr[i] = splitedStr[i].trim();
					
				}
				
	//자른 데이터를 원하는 형식에 맞게 넣기

				saleList.add(splitedStr);
			}

			
			//System.out.println(saleList.get(1)[0]);
			reader.close();

			File w_file = new File(".\\txt\\db1.txt");
			String str = "번호    "+"이름    "+"상품    \n";
			FileWriter writer = new FileWriter(w_file,true);
			BufferedWriter w = new BufferedWriter(writer);
			writer.write(str);
			for (int i = 0; i < saleList.size(); i++) {
				str =saleList.get(i)[0]+"\n";
				
				writer.write(str);
//				str =saleList.get(i)[0]+"\n";
			}
//			FileWriter writer = new FileWriter(w_file);
//			BufferedWriter w = new BufferedWriter(writer);
//			writer.write(str);
			w.close();

			
			

		} catch (FileNotFoundException fnf) {

			fnf.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}

	}

}
