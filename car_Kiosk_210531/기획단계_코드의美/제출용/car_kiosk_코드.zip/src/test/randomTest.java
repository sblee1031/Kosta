package test;

public class randomTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int random_carNum = (int)Math.floor((Math.random())*2);
			int m = (int)(Math.random()*4);
			System.out.println(m);
			System.out.println("random " +random_carNum);
	}

}
